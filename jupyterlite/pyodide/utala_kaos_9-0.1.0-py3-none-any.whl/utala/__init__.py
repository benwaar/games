"""
utala: kaos 9

A 2-player tactical grid combat card game research project.
Phase 1: Baselines and Instrumentation
"""

__version__ = "0.1.0"
